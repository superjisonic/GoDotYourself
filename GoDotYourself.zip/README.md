# cvlecture_opencv_webapp

OpenCV + WebApp General informations

Youtube video lists
https://www.youtube.com/playlist?list=PLvX6vpRszMkwECdbxNX8s9R-vcUFGqqtC

Facebook page 
https://www.facebook.com/pg/opencvlecture/ 

Github
https://github.com/MareArts/cvlecture_opencv_webapp

Target webapp
http://webapp.marearts.com/dtable

And  My computer vision study blog : http://study.marearts.com/
Thank you.


