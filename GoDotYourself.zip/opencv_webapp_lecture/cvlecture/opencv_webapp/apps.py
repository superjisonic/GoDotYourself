from django.apps import AppConfig


class OpencvWebappConfig(AppConfig):
    name = 'opencv_webapp'
